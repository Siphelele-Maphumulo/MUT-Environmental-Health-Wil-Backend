require("dotenv").config();
const express = require("express");
const mysql = require("mysql2/promise");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const bodyParser = require("body-parser");
const cors = require("cors");
const path = require("path");
const multer = require("multer");
const fs = require("fs");
const session = require("express-session");

const app = express();
const port = process.env.PORT || 8080;

// ======= MySQL Connection Pool ======= //
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

// ======= Middleware ======= //
app.use(express.json());
app.use(bodyParser.json());
app.use(
  cors({
    origin: "http://localhost:4200", // Allow requests from Angular frontend
    credentials: true,
  })
);

// Secret key for signing JWT (store this securely, e.g., in an environment variable)
const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";

// ======= Security Headers ======= //
app.use((req, res, next) => {
  console.log("Body:", req.body);
  console.log("Files:", req.files);
  res.setHeader(
    "Content-Security-Policy",
    "default-src 'self'; img-src 'self' data: http://localhost:8080"
  );
  res.setHeader("X-Content-Type-Options", "nosniff");
  next();
});

// ======= Session Middleware ======= //
app.use(
  session({
    secret: process.env.SESSION_SECRET || "your-secret-key", // Use a secure secret key
    resave: false,
    saveUninitialized: true,
    cookie: {
      httpOnly: true,
      secure: false, // Set to true if using HTTPS
      maxAge: 1000 * 60 * 60, // Session expires in 1 hour
    },
  })
);

// ======= Multer Configuration for File Uploads ======= //
const UPLOADS_PATH = path.join(__dirname, "uploads");

if (!fs.existsSync(UPLOADS_PATH)) {
  fs.mkdirSync(UPLOADS_PATH, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, UPLOADS_PATH);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, uniqueSuffix + "-" + file.originalname);
  },
});

const upload = multer({ storage });

// ======= Serve Uploaded Files ======= //
app.use("/uploads", express.static(UPLOADS_PATH));

// ======= Generate JWT Token ======= //
function generateToken(user) {
  return jwt.sign(
    { userId: user.id, email: user.email },
    JWT_SECRET,
    { expiresIn: "1h" } // Token expires in 1 hour
  );
}

// ======= Verify JWT Token Middleware ======= //
function authenticateToken(req, res, next) {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];

  if (!token) {
    return res
      .status(401)
      .json({ message: "Access denied. No token provided." });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ message: "Invalid or expired token." });
    }
    req.user = user;
    next();
  });
}

// isAuthenticated Middleware
function isAuthenticated(req, res, next) {
  // Extract the token from the Authorization header
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ message: "Unauthorized: Missing token" });
  }

  const token = authHeader.split(" ")[1]; // Extract the token after "Bearer"

  try {
    // Verify the token
    const decoded = jwt.verify(token, SECRET_KEY);

    // Attach the user information to the request object
    req.user = decoded;

    // Proceed to the next middleware/route handler
    next();
  } catch (error) {
    // Handle invalid or expired tokens
    return res.status(401).json({ message: "Unauthorized: Invalid token" });
  }
}

// Protected Route Example
app.get("/api/protected", isAuthenticated, (req, res) => {
  // Access the authenticated user's information from req.user
  res.json({ message: "You are authorized!", user: req.user });
});

// ======= Signup Route ======= //
app.post("/api/signup", async (req, res) => {
  const { email, title, password } = req.body;

  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const query = "INSERT INTO users (email, title, password) VALUES (?, ?, ?)";
    await pool.execute(query, [email, title, hashedPassword]);

    res.status(201).json({ message: "User registered successfully" });
  } catch (error) {
    console.error("Error during signup:", error);
    if (error.code === "ER_DUP_ENTRY") {
      return res.status(400).json({ message: "Email already exists" });
    }
    res.status(500).json({ message: "Signup failed" });
  }
});

// ======= Login Route ======= //
app.post("/api/login", async (req, res) => {
  const { email, password } = req.body;

  try {
    // Query the database for the user with the provided email
    const query = "SELECT * FROM users WHERE email = ?";
    const [results] = await pool.execute(query, [email]);

    // Check if the user exists
    if (results.length === 0) {
      return res.status(401).json({ message: "User not found" });
    }

    const user = results[0];

    // Compare the provided password with the hashed password in the database
    const isMatch = await bcrypt.compare(password, user.password);

    if (!isMatch) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    // Store the user's email in the session (server-side)
    req.session.userEmail = user.email;

    // Return the user's email in the response
    res.status(200).json({ message: "Login successful", email: user.email });
  } catch (error) {
    console.error("Error during login:", error);
    res.status(500).json({ message: "Login failed" });
  }
});

// ======= Logout Route ======= //
app.post("/api/logout", (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).json({ message: "Could not log out" });
    }
    res.status(200).json({ message: "Logged out successfully" });
  });
});

// ======= Protected Route Example ======= //
app.get("/api/student-dashboard", (req, res) => {
  const userEmail = req.session.userEmail;
  res.status(200).json({ message: `Welcome, ${userEmail}` });
});

// ======= Submit Student Application ======= //
app.post(
  "/api/applications",
  upload.fields([
    { name: "signatureImage", maxCount: 1 },
    { name: "idDocument", maxCount: 1 },
    { name: "cvDocument", maxCount: 1 },
  ]),
  async (req, res) => {
    try {
      const {
        province,
        title,
        initials,
        surname,
        firstNames,
        studentNumber,
        levelOfStudy,
        race,
        gender,
        emailAddress,
        physicalAddress,
        homeTown,
        cellPhoneNumber,
        municipalityName,
        townSituated,
        contactPerson,
        contactEmail,
        telephoneNumber,
        contactCellPhone,
        declarationInfo1,
        declarationInfo2,
        declarationInfo3,
      } = req.body;

      if (
        !req.files ||
        !req.files["signatureImage"] ||
        !req.files["idDocument"] ||
        !req.files["cvDocument"]
      ) {
        return res
          .status(400)
          .json({ message: "All file uploads are required" });
      }

      const signaturePath = path.join(
        "uploads",
        req.files["signatureImage"][0].filename
      );
      const idDocPath = path.join(
        "uploads",
        req.files["idDocument"][0].filename
      );
      const cvPath = path.join("uploads", req.files["cvDocument"][0].filename);

      const query = `
        INSERT INTO wil_application (
          province, title, initials, surname, first_names, student_number, level_of_study,
          race, gender, email_address, physical_address, home_town, cell_phone_number,
          municipality_name, town_situated, contact_person, contact_email, telephone_number,
          contact_cell_phone, declaration_info_1, declaration_info_2, declaration_info_3,
          signature_image, id_document, cv_document
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;

      const values = [
        province,
        title,
        initials,
        surname,
        firstNames,
        studentNumber,
        levelOfStudy,
        race,
        gender,
        emailAddress,
        physicalAddress,
        homeTown,
        cellPhoneNumber,
        municipalityName,
        townSituated,
        contactPerson,
        contactEmail,
        telephoneNumber,
        contactCellPhone,
        declarationInfo1 === "true" || declarationInfo1 === true,
        declarationInfo2 === "true" || declarationInfo2 === true,
        declarationInfo3 === "true" || declarationInfo3 === true,
        signaturePath,
        idDocPath,
        cvPath,
      ];

      const [result] = await pool.execute(query, values);

      res.status(201).json({
        message: "Student application submitted successfully.",
        applicationId: result.insertId,
      });
    } catch (error) {
      console.error("Error submitting application:", error);
      res.status(500).json({ message: "Failed to submit application" });
    }
  }
);

// API Endpoint to Submit Daily Log Sheet
// ======= Submit Daily Log Sheet ======= //
// API Endpoint to Submit Daily Log Sheet
app.post(
  "/api/submit-logsheet",
  upload.fields([
    { name: "student_signature", maxCount: 1 },
    { name: "supervisor_signature", maxCount: 1 },
  ]),
  async (req, res) => {
    try {
      const {
        logDate,
        studentNumber,
        EHP_HI_Number, // Extract EHP_HI_Number
        activities,
        description,
        situationDescription,
        situationEvaluation,
        situationInterpretation,
        dateStamp,
      } = req.body;

      // Validate required fields
      if (!logDate || !studentNumber || !EHP_HI_Number || !activities) {
        return res.status(400).json({
          message:
            "Missing required fields. Please provide logDate, studentNumber, EHP_HI_Number, and activities.",
        });
      }

      // Parse activities array
      let parsedActivities;
      try {
        parsedActivities = JSON.parse(activities);
      } catch (error) {
        return res.status(400).json({
          message: "Invalid activities format. Must be a valid JSON array.",
        });
      }

      // Access uploaded files
      const studentSignature = req.files["student_signature"]?.[0]?.filename;
      const supervisorSignature =
        req.files["supervisor_signature"]?.[0]?.filename;

      // Prepare SQL query
      const sql = `
        INSERT INTO daily_logsheet (
          log_date,
          student_number,
          EHP_HI_Number, -- Add this column
          activity1, hours1,
          activity2, hours2,
          activity3, hours3,
          activity4, hours4,
          activity5, hours5,
          activity6, hours6,
          activity7, hours7,
          activity8, hours8,
          activity9, hours9,
          activity10, hours10,
          activity11, hours11,
          activity12, hours12,
          activity13, hours13,
          activity14, hours14,
          description,
          situation_description,
          situation_evaluation,
          situation_interpretation,
          student_signature,
          supervisor_signature,
          date_stamp
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;

      // Flatten activities into individual values
      const values = [
        logDate,
        studentNumber,
        EHP_HI_Number, // Include EHP_HI_Number here
        parsedActivities[0]?.activity || null,
        parsedActivities[0]?.hours || null,
        parsedActivities[1]?.activity || null,
        parsedActivities[1]?.hours || null,
        parsedActivities[2]?.activity || null,
        parsedActivities[2]?.hours || null,
        parsedActivities[3]?.activity || null,
        parsedActivities[3]?.hours || null,
        parsedActivities[4]?.activity || null,
        parsedActivities[4]?.hours || null,
        parsedActivities[5]?.activity || null,
        parsedActivities[5]?.hours || null,
        parsedActivities[6]?.activity || null,
        parsedActivities[6]?.hours || null,
        parsedActivities[7]?.activity || null,
        parsedActivities[7]?.hours || null,
        parsedActivities[8]?.activity || null,
        parsedActivities[8]?.hours || null,
        parsedActivities[9]?.activity || null,
        parsedActivities[9]?.hours || null,
        parsedActivities[10]?.activity || null,
        parsedActivities[10]?.hours || null,
        parsedActivities[11]?.activity || null,
        parsedActivities[11]?.hours || null,
        parsedActivities[12]?.activity || null,
        parsedActivities[12]?.hours || null,
        parsedActivities[13]?.activity || null,
        parsedActivities[13]?.hours || null,
        description || null,
        situationDescription || null,
        situationEvaluation || null,
        situationInterpretation || null,
        studentSignature || null,
        supervisorSignature || null,
        dateStamp || null,
      ];

      // Execute query
      await pool.execute(sql, values);

      // Return success response
      res.status(200).json({ message: "Log sheet submitted successfully!" });
    } catch (error) {
      console.error("Error submitting log sheet:", error);
      res.status(500).json({
        message: "Failed to submit log sheet",
        error: error.message,
      });
    }
  }
);

// ======= Get All Student Applications ======= //
app.get("/api/applications", async (req, res) => {
  try {
    const [rows] = await pool.execute("SELECT * FROM wil_application");

    const applications = rows.map((row) => ({
      ...row,
      signature_image: `http://localhost:${port}/${row.signature_image}`,
      id_document: `http://localhost:${port}/${row.id_document}`,
      cv_document: `http://localhost:${port}/${row.cv_document}`,
    }));

    res.status(200).json(applications);
  } catch (error) {
    console.error("Error fetching student applications:", error);
    res.status(500).json({ message: "Failed to retrieve applications." });
  }
});

// ======= Get All Daily Log Sheets ======= //
app.get("/api/daily-logsheets", async (req, res) => {
  try {
    // Fetch all rows from the daily_logsheet table
    const [rows] = await pool.execute("SELECT * FROM daily_logsheet");

    // Map the rows and filter out null values for each log sheet
    const logSheets = rows.map((row) => {
      const filteredRow = {};

      // Iterate through each key-value pair in the row
      for (const key in row) {
        // Skip null/undefined values except for special fields
        if (row[key] !== null && row[key] !== undefined) {
          // Handle special fields
          if (key === "student_signature" || key === "supervisor_signature") {
            // Only include signature URLs if file exists
            if (row[key]) {
              filteredRow[key] = `http://localhost:${port}/uploads/${row[key]}`;
            }
          }
          // Skip null activities and hours
          else if (key.startsWith("activity") || key.startsWith("hours")) {
            if (row[key] !== null) {
              filteredRow[key] = row[key];
            }
          }
          // Include all other non-null fields
          else {
            filteredRow[key] = row[key];
          }
        }
      }

      return filteredRow;
    });

    // Send the filtered log sheets as a JSON response
    res.status(200).json(logSheets);
  } catch (error) {
    console.error("Error fetching daily log sheets:", error);
    res.status(500).json({ message: "Failed to retrieve daily log sheets." });
  }
});

// ======= Update Daily Log Sheet ======= //
app.put(
  "/api/update-logsheets/:id",
  upload.fields([
    { name: "student_signature" },
    { name: "supervisor_signature" },
  ]),
  async (req, res) => {
    const { id } = req.params;
    const {
      date, // renaming to log_date if necessary
      activity1,
      hours1,
      description,
      situation,
      evaluation,
      interpretation,
      supervisor_hi_number,
      date_stamp,
    } = req.body;

    // Handle file uploads (if present)
    const student_signature = req.files["student_signature"]
      ? req.files["student_signature"][0].filename
      : null;
    const supervisor_signature = req.files["supervisor_signature"]
      ? req.files["supervisor_signature"][0].filename
      : null;

    // Debugging: log the request data
    console.log("Request Body:", req.body);
    console.log("Files received:", req.files);

    // Ensure required fields are provided, else set as NULL
    const safeDate = date || null;
    const safeActivity1 = activity1 || null;
    const safeHours1 = hours1 || null;
    const safeDescription = description || null;
    const safeSituation = situation || null;
    const safeEvaluation = evaluation || null;
    const safeInterpretation = interpretation || null;
    const safeSupervisorHiNumber = supervisor_hi_number || null;
    const safeDateStamp = date_stamp || null;

    // If file paths are null, log that for debugging
    if (!student_signature || !supervisor_signature) {
      console.log("Missing student or supervisor signature file.");
    }

    try {
      const [result] = await pool.execute(
        `UPDATE daily_logsheet SET 
          log_date = ?,  -- Changed from 'date' to 'log_date'
          activity1 = ?, 
          hours1 = ?, 
          description = ?, 
          situation_description = ?,  -- Ensure this matches your column name
          situation_evaluation = ?,  -- Ensure this matches your column name
          situation_interpretation = ?,  -- Ensure this matches your column name
          student_signature = ?, 
          supervisor_signature = ?, 
          EHP_HI_Number = ?, 
          date_stamp = ?, 
          created_at = CURRENT_TIMESTAMP
         WHERE id = ?`,
        [
          safeDate,
          safeActivity1,
          safeHours1,
          safeDescription,
          safeSituation, // situation_description column if needed
          safeEvaluation, // situation_evaluation column if needed
          safeInterpretation, // situation_interpretation column if needed
          student_signature,
          supervisor_signature,
          safeSupervisorHiNumber,
          safeDateStamp,
          id,
        ]
      );

      res.status(200).json({ message: "Logsheet updated successfully!" });
    } catch (error) {
      console.error("Update error:", error);
      res.status(500).json({ error: "Failed to update logsheet" });
    }
  }
);

// ======= Start the Server ======= //
app.listen(port, () => {
  console.log(`🚀 Server running at: http://localhost:${port}`);
});
